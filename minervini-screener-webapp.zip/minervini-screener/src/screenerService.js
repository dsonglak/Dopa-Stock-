export async function analyzeStock(sym, price, name) {
  const prompt = `You are a stock market expert applying Mark Minervini's Trend Template to evaluate ${sym} (${name}).

Today is May 21, 2026. Current price: $${price}.

Based on your knowledge of this stock's recent price action, moving averages, and relative strength as of mid-May 2026, evaluate each of the 8 Trend Template criteria:

C1: Current price is ABOVE both the 150-day SMA AND 200-day SMA
C2: The 150-day SMA is ABOVE the 200-day SMA
C3: The 200-day SMA has been trending UP for at least 1 month
C4: The 50-day SMA is ABOVE both the 150-day SMA and 200-day SMA
C5: Current price is ABOVE the 50-day SMA
C6: Current price is at least 25% ABOVE the 52-week low
C7: Current price is WITHIN 25% of the 52-week high (i.e., price >= 0.75 × 52wk high)
C8: Relative Strength vs S&P 500 is strong — stock has outperformed the market (RS rating >= 70 equivalent)

For each criterion, use your best knowledge of ${sym}'s actual recent market data. Be realistic and accurate.

Respond ONLY with a valid JSON object, no preamble, no markdown:
{"c1":true,"c2":true,"c3":true,"c4":true,"c5":true,"c6":true,"c7":true,"c8":true,"note":"brief 1-sentence analysis in Thai"}

Use true or false for each. Be accurate based on real market conditions as of May 2026.`;

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 300,
      messages: [{ role: 'user', content: prompt }],
    }),
  });

  if (!response.ok) throw new Error(`API error ${response.status}`);
  const data = await response.json();
  const text = data.content?.map(b => b.text || '').join('') || '';
  const match = text.replace(/```json|```/g, '').trim().match(/\{[\s\S]*\}/);
  if (!match) throw new Error('No JSON in response');
  const parsed = JSON.parse(match[0]);
  const criteria = [parsed.c1, parsed.c2, parsed.c3, parsed.c4, parsed.c5, parsed.c6, parsed.c7, parsed.c8];
  const score = criteria.filter(Boolean).length;
  return { criteria, score, note: parsed.note || '' };
}

export function exportCSV(results, stocks) {
  const headers = ['Rank','Symbol','Company','Price','Market Cap','Score','C1','C2','C3','C4','C5','C6','C7','C8','Verdict','Note'];
  const rows = stocks.map(s => {
    const r = results[s.sym];
    if (!r) return [s.r, s.sym, s.name, s.price, s.mc, '', ...Array(8).fill(''), 'PENDING', ''];
    const verdict = r.score === 8 ? 'PASS' : r.score >= 6 ? 'REVIEW' : 'FAIL';
    return [s.r, s.sym, `"${s.name}"`, s.price, s.mc, r.score, ...r.criteria.map(c => c ? 'TRUE' : 'FALSE'), verdict, `"${r.note}"`];
  });
  const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `minervini_scan_${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
