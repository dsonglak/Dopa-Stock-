import { useState, useEffect, useRef, useCallback } from 'react';
import { TOP100, CRITERIA_LABELS } from './stockData';
import { analyzeStock, exportCSV } from './screenerService';

/* ─── STYLES ─── */
const css = `
  @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=IBM+Plex+Mono:wght@300;400;600&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg: #080a0c; --s1: #0e1114; --s2: #141820;
    --border: #1c2128; --border2: #252c38;
    --gold: #f0b429; --gold-dim: rgba(240,180,41,0.12);
    --green: #00e676; --green-dim: rgba(0,230,118,0.10);
    --red: #ff3d57; --red-dim: rgba(255,61,87,0.10);
    --yellow: #ffd740; --yellow-dim: rgba(255,215,64,0.10);
    --muted: #3d4552; --text: #dde3ec; --dim: #6b7585;
  }
  html, body, #root { height: 100%; }
  body { background: var(--bg); color: var(--text); font-family: 'IBM Plex Sans', sans-serif; }
  body::after {
    content: ''; position: fixed; inset: 0; pointer-events: none; z-index: 0;
    background: radial-gradient(ellipse 60% 40% at 80% 10%, rgba(240,180,41,0.04) 0%, transparent 60%),
                radial-gradient(ellipse 50% 50% at 20% 90%, rgba(0,230,118,0.03) 0%, transparent 60%);
  }
  @keyframes shimmer { 0%,100%{opacity:.25} 50%{opacity:.6} }
  @keyframes fadeIn { from{opacity:0;transform:translateY(4px)} to{opacity:1;transform:none} }
  @keyframes spin { to { transform: rotate(360deg); } }
`;

/* ─── TOKEN COLORS ─── */
const C = {
  pass:   { bg: 'var(--green-dim)',  border: 'rgba(0,230,118,.3)',  text: 'var(--green)' },
  review: { bg: 'var(--yellow-dim)', border: 'rgba(255,215,64,.3)', text: 'var(--yellow)' },
  fail:   { bg: 'var(--red-dim)',    border: 'rgba(255,61,87,.3)',  text: 'var(--red)' },
  pending:{ bg: 'transparent',       border: 'var(--muted)',         text: 'var(--muted)' },
};
const verdict = score => score === 8 ? 'pass' : score >= 6 ? 'review' : 'fail';

/* ─── HELPERS ─── */
const LS_KEY = 'minervini_results_v2';
const LS_WL  = 'minervini_watchlist_v1';
const saveResults = r => { try { localStorage.setItem(LS_KEY, JSON.stringify(r)); } catch {} };
const loadResults = () => { try { return JSON.parse(localStorage.getItem(LS_KEY) || 'null'); } catch { return null; } };
const saveWatchlist = w => { try { localStorage.setItem(LS_WL, JSON.stringify(w)); } catch {} };
const loadWatchlist = () => { try { return JSON.parse(localStorage.getItem(LS_WL) || '[]'); } catch { return []; } };

/* ═══════════════════════════════════════════════
   MAIN APP
═══════════════════════════════════════════════ */
export default function App() {
  const [results, setResults]     = useState(loadResults() || {});
  const [scanning, setScanning]   = useState(false);
  const [progress, setProgress]   = useState(0);
  const [statusMsg, setStatusMsg] = useState('กด RUN SCREENER เพื่อเริ่มวิเคราะห์');
  const [filter, setFilter]       = useState('all');
  const [search, setSearch]       = useState('');
  const [expanded, setExpanded]   = useState(null);
  const [tab, setTab]             = useState('screener'); // screener | watchlist | history
  const [watchlist, setWatchlist] = useState(loadWatchlist());
  const [customInput, setCustomInput] = useState('');
  const [customStocks, setCustomStocks] = useState([]);
  const [sortKey, setSortKey]     = useState('rank');
  const [sortDir, setSortDir]     = useState(1);
  const [history, setHistory]     = useState(() => { try { return JSON.parse(localStorage.getItem('minervini_history') || '[]'); } catch { return []; } });
  const abortRef = useRef(false);

  useEffect(() => { saveResults(results); }, [results]);
  useEffect(() => { saveWatchlist(watchlist); }, [watchlist]);

  /* all stocks = top100 + custom */
  const allStocks = [...TOP100, ...customStocks];

  /* ─── stats ─── */
  const scanned  = Object.keys(results).length;
  const passCount = Object.values(results).filter(r => r.score === 8).length;
  const revCount  = Object.values(results).filter(r => r.score >= 6 && r.score < 8).length;
  const failCount = Object.values(results).filter(r => r.score < 6).length;

  /* ─── run screener ─── */
  const runScreener = useCallback(async (stockList = null) => {
    if (scanning) { abortRef.current = true; return; }
    abortRef.current = false;
    setScanning(true);
    setProgress(0);
    const targets = stockList || allStocks;
    const total = targets.length;
    let done = 0;

    const BATCH = 3;
    for (let i = 0; i < total; i += BATCH) {
      if (abortRef.current) break;
      const batch = targets.slice(i, i + BATCH);
      setStatusMsg(`Analyzing ${batch.map(s => s.sym).join(', ')} ... (${i + 1}–${Math.min(i + BATCH, total)} / ${total})`);

      await Promise.all(batch.map(async s => {
        try {
          const res = await analyzeStock(s.sym, s.price, s.name);
          setResults(prev => ({ ...prev, [s.sym]: res }));
        } catch (e) {
          setResults(prev => ({ ...prev, [s.sym]: { criteria: Array(8).fill(null), score: 0, note: 'Error: ' + e.message } }));
        }
        done++;
        setProgress(Math.round((done / total) * 100));
      }));

      if (i + BATCH < total) await new Promise(r => setTimeout(r, 350));
    }

    const ts = new Date().toLocaleString('th-TH');
    setStatusMsg(`Scan เสร็จสิ้น ${total} หุ้น — ${ts}`);
    setScanning(false);

    // Save to history
    setHistory(prev => {
      const entry = { ts, scanned: total, passCount, revCount };
      const next = [entry, ...prev].slice(0, 20);
      localStorage.setItem('minervini_history', JSON.stringify(next));
      return next;
    });
  // eslint-disable-next-line
  }, [scanning, allStocks]);

  /* ─── add custom stock ─── */
  const addCustomStock = () => {
    const parts = customInput.toUpperCase().trim().split(/[\s,]+/).filter(Boolean);
    const newStocks = parts
      .filter(sym => !allStocks.find(s => s.sym === sym))
      .map((sym, i) => ({ r: TOP100.length + customStocks.length + i + 1, sym, name: sym, mc: '—', price: 0, custom: true }));
    setCustomStocks(prev => [...prev, ...newStocks]);
    setCustomInput('');
  };

  const removeCustom = sym => setCustomStocks(prev => prev.filter(s => s.sym !== sym));

  /* ─── toggle watchlist ─── */
  const toggleWL = sym => {
    setWatchlist(prev => prev.includes(sym) ? prev.filter(s => s !== sym) : [...prev, sym]);
  };

  /* ─── sort ─── */
  const handleSort = key => {
    if (sortKey === key) setSortDir(d => -d);
    else { setSortKey(key); setSortDir(1); }
  };

  /* ─── filter + sort visible stocks ─── */
  const visibleStocks = allStocks
    .filter(s => {
      const r = results[s.sym];
      const score = r ? r.score : -1;
      const verd = r ? verdict(score) : 'pending';
      if (filter === 'pass' && verd !== 'pass') return false;
      if (filter === 'review' && verd !== 'review') return false;
      if (filter === 'fail' && verd !== 'fail') return false;
      if (filter === 'watchlist' && !watchlist.includes(s.sym)) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!s.sym.toLowerCase().includes(q) && !s.name.toLowerCase().includes(q)) return false;
      }
      return true;
    })
    .sort((a, b) => {
      const ra = results[a.sym], rb = results[b.sym];
      if (sortKey === 'score') return ((rb?.score ?? -1) - (ra?.score ?? -1)) * sortDir;
      if (sortKey === 'sym') return a.sym.localeCompare(b.sym) * sortDir;
      return (a.r - b.r) * sortDir;
    });

  /* ─── watchlist stocks with results ─── */
  const wlStocks = allStocks.filter(s => watchlist.includes(s.sym));

  return (
    <>
      <style>{css}</style>
      <div style={{ position: 'relative', zIndex: 1, minHeight: '100vh' }}>

        {/* ══ SIDEBAR ══ */}
        <div style={{ display: 'flex', minHeight: '100vh' }}>
          <Sidebar tab={tab} setTab={setTab} passCount={passCount} revCount={revCount} wlCount={watchlist.length} />

          {/* ══ MAIN CONTENT ══ */}
          <div style={{ flex: 1, padding: '32px 28px 80px', overflow: 'auto' }}>

            {/* HEADER */}
            <Header />

            {/* ── TAB: SCREENER ── */}
            {tab === 'screener' && (
              <>
                <StatsBar scanned={scanned} total={allStocks.length} passCount={passCount} revCount={revCount} failCount={failCount} />
                <ProgressBar progress={progress} scanning={scanning} />
                <StatusBar msg={statusMsg} />

                {/* Controls */}
                <ControlBar
                  scanning={scanning}
                  onRun={() => runScreener()}
                  onStop={() => { abortRef.current = true; }}
                  filter={filter} setFilter={setFilter}
                  search={search} setSearch={setSearch}
                  onExport={() => exportCSV(results, allStocks)}
                  onClearResults={() => { setResults({}); localStorage.removeItem(LS_KEY); setStatusMsg('Results cleared.'); }}
                />

                {/* Custom Stock Input */}
                <CustomInput
                  value={customInput}
                  onChange={setCustomInput}
                  onAdd={addCustomStock}
                  customStocks={customStocks}
                  onRemove={removeCustom}
                  onRunCustom={() => runScreener(customStocks)}
                />

                {/* Sort header */}
                <SortHeader sortKey={sortKey} sortDir={sortDir} onSort={handleSort} />

                {/* Stock rows */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  {visibleStocks.length === 0 && (
                    <div style={{ textAlign: 'center', padding: '60px 20px', fontFamily: "'IBM Plex Mono',monospace", fontSize: 12, color: 'var(--dim)' }}>
                      ไม่พบหุ้นที่ตรงเงื่อนไข
                    </div>
                  )}
                  {visibleStocks.map(s => (
                    <StockRow
                      key={s.sym}
                      stock={s}
                      result={results[s.sym]}
                      expanded={expanded === s.sym}
                      onExpand={() => setExpanded(expanded === s.sym ? null : s.sym)}
                      inWL={watchlist.includes(s.sym)}
                      onToggleWL={() => toggleWL(s.sym)}
                    />
                  ))}
                </div>
              </>
            )}

            {/* ── TAB: WATCHLIST ── */}
            {tab === 'watchlist' && (
              <WatchlistTab stocks={wlStocks} results={results} onRemove={toggleWL} onRunWL={() => runScreener(wlStocks)} scanning={scanning} />
            )}

            {/* ── TAB: HISTORY ── */}
            {tab === 'history' && <HistoryTab history={history} />}

          </div>
        </div>
      </div>
    </>
  );
}

/* ═══════════════════════════════════════════════
   SUB-COMPONENTS
═══════════════════════════════════════════════ */

function Sidebar({ tab, setTab, passCount, revCount, wlCount }) {
  const items = [
    { id: 'screener', icon: '◈', label: 'Screener' },
    { id: 'watchlist', icon: '★', label: `Watchlist (${wlCount})` },
    { id: 'history', icon: '◷', label: 'History' },
  ];
  return (
    <div style={{ width: 64, background: 'var(--s1)', borderRight: '1px solid var(--border)', display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 24, gap: 4, flexShrink: 0 }}>
      {items.map(it => (
        <button key={it.id} onClick={() => setTab(it.id)}
          title={it.label}
          style={{
            width: 44, height: 44, background: tab === it.id ? 'var(--gold-dim)' : 'transparent',
            border: tab === it.id ? '1px solid rgba(240,180,41,.3)' : '1px solid transparent',
            color: tab === it.id ? 'var(--gold)' : 'var(--dim)', cursor: 'pointer',
            fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'all .15s'
          }}>
          {it.icon}
        </button>
      ))}
      <div style={{ flex: 1 }} />
      {passCount > 0 && (
        <div style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 28, color: 'var(--green)', lineHeight: 1, marginBottom: 4 }}>{passCount}</div>
      )}
      {revCount > 0 && (
        <div style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 28, color: 'var(--yellow)', lineHeight: 1, marginBottom: 16 }}>{revCount}</div>
      )}
    </div>
  );
}

function Header() {
  return (
    <div style={{ marginBottom: 28 }}>
      <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 9, letterSpacing: '.15em', color: 'var(--gold)', border: '1px solid rgba(240,180,41,.3)', padding: '3px 10px', display: 'inline-block', marginBottom: 10, textTransform: 'uppercase' }}>
        SEPA Methodology — Minervini
      </div>
      <h1 style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 'clamp(32px,5vw,56px)', letterSpacing: '.04em', lineHeight: .92, color: '#fff' }}>
        TREND TEMPLATE <span style={{ color: 'var(--gold)' }}>SCREENER</span>
      </h1>
      <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 10, letterSpacing: '.08em', color: 'var(--dim)', marginTop: 8 }}>
        // TOP 100 US STOCKS • 8-CRITERIA FILTER • AI-POWERED • MAY 2026
      </div>
    </div>
  );
}

function StatsBar({ scanned, total, passCount, revCount, failCount }) {
  const stats = [
    { label: 'Total Stocks',    val: total,    color: 'var(--text)' },
    { label: 'Scanned',         val: scanned,  color: 'var(--dim)' },
    { label: 'Full Pass (8/8)', val: passCount, color: 'var(--green)' },
    { label: 'Near Setup (6–7)',val: revCount,  color: 'var(--yellow)' },
    { label: 'Fail',            val: failCount, color: 'var(--red)' },
  ];
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 1, background: 'var(--border)', marginBottom: 12 }}>
      {stats.map(s => (
        <div key={s.label} style={{ background: 'var(--s1)', padding: '12px 14px' }}>
          <div style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 28, color: s.color, lineHeight: 1 }}>{s.val || '—'}</div>
          <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 8, letterSpacing: '.1em', color: 'var(--dim)', textTransform: 'uppercase', marginTop: 2 }}>{s.label}</div>
        </div>
      ))}
    </div>
  );
}

function ProgressBar({ progress, scanning }) {
  return (
    <div style={{ height: 2, background: 'var(--border)', marginBottom: 10 }}>
      <div style={{ height: '100%', width: progress + '%', background: scanning ? 'linear-gradient(90deg,var(--gold),var(--green))' : 'var(--green)', transition: 'width .3s ease' }} />
    </div>
  );
}

function StatusBar({ msg }) {
  return (
    <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 10, color: 'var(--dim)', letterSpacing: '.06em', marginBottom: 14, minHeight: 16 }}>
      // {msg}
    </div>
  );
}

function ControlBar({ scanning, onRun, onStop, filter, setFilter, search, setSearch, onExport, onClearResults }) {
  const filters = [
    { id: 'all', label: 'ALL', activeKey: 'active-all' },
    { id: 'pass', label: '✓ PASS', activeKey: 'active-pass' },
    { id: 'review', label: '⚡ 6–7', activeKey: 'active-review' },
    { id: 'fail', label: '✕ FAIL', activeKey: 'active-fail' },
    { id: 'watchlist', label: '★ WL', activeKey: 'active-wl' },
  ];
  const filterColors = { 'all': 'var(--gold)', 'pass': 'var(--green)', 'review': 'var(--yellow)', 'fail': 'var(--red)', 'watchlist': 'var(--gold)' };

  return (
    <div style={{ display: 'flex', gap: 10, marginBottom: 14, flexWrap: 'wrap', alignItems: 'center' }}>
      <button
        onClick={scanning ? onStop : onRun}
        style={{
          fontFamily: "'IBM Plex Mono',monospace", fontSize: 11, fontWeight: 600,
          letterSpacing: '.1em', textTransform: 'uppercase',
          background: scanning ? 'var(--red)' : 'var(--gold)', color: '#000',
          border: 'none', padding: '10px 22px', cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
        {scanning
          ? <><span style={{ display: 'inline-block', animation: 'spin 1s linear infinite', fontSize: 13 }}>⟳</span> STOP</>
          : '▶ RUN SCREENER'}
      </button>

      <div style={{ display: 'flex', gap: 3 }}>
        {filters.map(f => (
          <button key={f.id} onClick={() => setFilter(f.id)}
            style={{
              fontFamily: "'IBM Plex Mono',monospace", fontSize: 9, letterSpacing: '.08em',
              border: `1px solid ${filter === f.id ? filterColors[f.id] : 'var(--border)'}`,
              background: filter === f.id ? `${filterColors[f.id]}18` : 'transparent',
              color: filter === f.id ? filterColors[f.id] : 'var(--dim)',
              padding: '7px 12px', cursor: 'pointer', textTransform: 'uppercase', transition: 'all .15s'
            }}>{f.label}</button>
        ))}
      </div>

      <input
        value={search} onChange={e => setSearch(e.target.value)}
        placeholder="Search ticker / name..."
        style={{
          fontFamily: "'IBM Plex Mono',monospace", fontSize: 11,
          background: 'var(--s1)', border: '1px solid var(--border)', color: 'var(--text)',
          padding: '8px 12px', outline: 'none', width: 180,
        }}
      />

      <button onClick={onExport}
        style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 9, letterSpacing: '.1em', textTransform: 'uppercase', border: '1px solid var(--border)', background: 'transparent', color: 'var(--dim)', padding: '8px 14px', cursor: 'pointer' }}>
        ↓ CSV
      </button>
      <button onClick={onClearResults}
        style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 9, letterSpacing: '.1em', textTransform: 'uppercase', border: '1px solid var(--border)', background: 'transparent', color: 'var(--dim)', padding: '8px 14px', cursor: 'pointer' }}>
        ✕ Clear
      </button>
    </div>
  );
}

function CustomInput({ value, onChange, onAdd, customStocks, onRemove, onRunCustom }) {
  return (
    <div style={{ background: 'var(--s1)', border: '1px solid var(--border)', padding: '12px 16px', marginBottom: 14 }}>
      <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 9, letterSpacing: '.12em', color: 'var(--gold)', textTransform: 'uppercase', marginBottom: 8 }}>+ เพิ่มหุ้นเอง</div>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
        <input
          value={value}
          onChange={e => onChange(e.target.value.toUpperCase())}
          onKeyDown={e => e.key === 'Enter' && onAdd()}
          placeholder="PLTR, CRWD, MSTR ..."
          style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 11, background: 'var(--s2)', border: '1px solid var(--border2)', color: 'var(--text)', padding: '7px 12px', outline: 'none', width: 220 }}
        />
        <button onClick={onAdd}
          style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 9, letterSpacing: '.1em', textTransform: 'uppercase', border: '1px solid var(--gold)', background: 'var(--gold-dim)', color: 'var(--gold)', padding: '8px 16px', cursor: 'pointer' }}>
          ADD
        </button>
        {customStocks.length > 0 && (
          <button onClick={onRunCustom}
            style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 9, letterSpacing: '.1em', textTransform: 'uppercase', border: '1px solid var(--green)', background: 'var(--green-dim)', color: 'var(--green)', padding: '8px 16px', cursor: 'pointer' }}>
            SCAN CUSTOM ONLY
          </button>
        )}
        {customStocks.map(s => (
          <span key={s.sym} style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 11, color: 'var(--text)', background: 'var(--s2)', border: '1px solid var(--border2)', padding: '4px 10px', display: 'flex', alignItems: 'center', gap: 6 }}>
            {s.sym}
            <span onClick={() => onRemove(s.sym)} style={{ cursor: 'pointer', color: 'var(--dim)', fontSize: 13 }}>✕</span>
          </span>
        ))}
      </div>
    </div>
  );
}

function SortHeader({ sortKey, sortDir, onSort }) {
  const cols = [
    { key: 'rank', label: '#', w: 40 },
    { key: 'sym', label: 'Symbol', w: 90 },
    { key: null, label: 'Company', w: 180 },
    { key: null, label: 'Price', w: 90 },
    { key: null, label: 'Mkt Cap', w: 80 },
    { key: 'score', label: 'Score', w: 70 },
    { key: null, label: 'C1–C8', w: 100 },
    { key: null, label: 'Verdict', w: 100 },
    { key: null, label: '', w: 60 },
  ];
  return (
    <div style={{ display: 'flex', alignItems: 'center', padding: '8px 12px', borderBottom: '1px solid var(--border)', marginBottom: 4, gap: 8 }}>
      {cols.map((c, i) => (
        <div key={i} style={{ width: c.w, flexShrink: 0, fontFamily: "'IBM Plex Mono',monospace", fontSize: 8, letterSpacing: '.12em', textTransform: 'uppercase', color: c.key ? 'var(--gold)' : 'var(--dim)', cursor: c.key ? 'pointer' : 'default', userSelect: 'none' }}
          onClick={() => c.key && onSort(c.key)}>
          {c.label}{c.key === sortKey ? (sortDir === 1 ? ' ↑' : ' ↓') : ''}
        </div>
      ))}
    </div>
  );
}

function StockRow({ stock: s, result: r, expanded, onExpand, inWL, onToggleWL }) {
  const score = r ? r.score : -1;
  const verd = r ? verdict(score) : 'pending';
  const vc = C[verd];

  return (
    <div style={{ animation: 'fadeIn .2s ease' }}>
      <div
        style={{
          display: 'flex', alignItems: 'center', gap: 8, padding: '10px 12px',
          background: expanded ? 'var(--s2)' : 'var(--s1)',
          borderLeft: `2px solid ${verd === 'pass' ? 'var(--green)' : verd === 'review' ? 'var(--yellow)' : verd === 'fail' ? 'var(--red)' : 'var(--muted)'}`,
          cursor: 'pointer', transition: 'background .1s',
        }}
        onClick={onExpand}
      >
        {/* Rank */}
        <div style={{ width: 40, fontFamily: "'IBM Plex Mono',monospace", fontSize: 10, color: 'var(--dim)', flexShrink: 0 }}>{s.r}</div>

        {/* Symbol */}
        <div style={{ width: 90, fontFamily: "'Bebas Neue',sans-serif", fontSize: 20, letterSpacing: '.04em', color: '#fff', flexShrink: 0 }}>{s.sym}</div>

        {/* Name */}
        <div style={{ width: 180, fontSize: 11, color: 'var(--dim)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flexShrink: 0 }}>{s.name}</div>

        {/* Price */}
        <div style={{ width: 90, fontFamily: "'IBM Plex Mono',monospace", fontSize: 12, fontWeight: 600, flexShrink: 0 }}>
          {s.price > 0 ? `$${s.price.toLocaleString()}` : '—'}
        </div>

        {/* Mkt Cap */}
        <div style={{ width: 80, fontFamily: "'IBM Plex Mono',monospace", fontSize: 11, color: 'var(--dim)', flexShrink: 0 }}>{s.mc}</div>

        {/* Score */}
        <div style={{ width: 70, flexShrink: 0 }}>
          {r ? (
            <span style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 22, color: vc.text }}>{score}/8</span>
          ) : (
            <span style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 11, color: 'var(--muted)' }}>—</span>
          )}
        </div>

        {/* Dots */}
        <div style={{ width: 100, display: 'flex', gap: 3, flexShrink: 0 }}>
          {Array(8).fill(0).map((_, i) => {
            const c = r ? r.criteria[i] : null;
            return <div key={i} style={{ width: 9, height: 9, borderRadius: '50%', background: c === true ? 'var(--green)' : c === false ? 'var(--red)' : 'var(--muted)', opacity: c === null ? .35 : 1 }} />;
          })}
        </div>

        {/* Verdict */}
        <div style={{ width: 100, flexShrink: 0 }}>
          <span style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 9, letterSpacing: '.08em', fontWeight: 600, textTransform: 'uppercase', padding: '3px 8px', border: `1px solid ${vc.border}`, background: vc.bg, color: vc.text }}>
            {verd === 'pass' ? '✓ PASS' : verd === 'review' ? '⚡ REVIEW' : verd === 'fail' ? '✕ FAIL' : '— PENDING'}
          </span>
        </div>

        {/* Actions */}
        <div style={{ display: 'flex', gap: 6, marginLeft: 'auto' }} onClick={e => e.stopPropagation()}>
          <button onClick={onToggleWL}
            title={inWL ? 'Remove from watchlist' : 'Add to watchlist'}
            style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 13, background: 'none', border: 'none', cursor: 'pointer', color: inWL ? 'var(--gold)' : 'var(--muted)', padding: '2px 6px' }}>
            {inWL ? '★' : '☆'}
          </button>
          <span style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 10, color: 'var(--dim)', alignSelf: 'center' }}>{expanded ? '▾' : '▸'}</span>
        </div>
      </div>

      {/* EXPANDED DETAIL */}
      {expanded && r && (
        <div style={{ background: 'var(--s2)', borderLeft: `2px solid ${vc.border}`, padding: '16px 20px', display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8 }}>
          {CRITERIA_LABELS.map((cl, i) => {
            const pass = r.criteria[i];
            const col = pass === true ? 'var(--green)' : pass === false ? 'var(--red)' : 'var(--muted)';
            return (
              <div key={i} style={{ background: 'var(--s1)', border: '1px solid var(--border)', padding: '10px 12px' }}>
                <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 8, letterSpacing: '.12em', color: 'var(--gold)', marginBottom: 4 }}>{cl.code}</div>
                <div style={{ fontSize: 11, color: 'var(--text)', lineHeight: 1.5 }}>{cl.label}</div>
                <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 10, color: col, marginTop: 6, fontWeight: 600 }}>
                  {pass === true ? '✓ PASS' : pass === false ? '✕ FAIL' : '— N/A'}
                </div>
              </div>
            );
          })}
          {r.note && (
            <div style={{ gridColumn: '1/-1', fontFamily: "'IBM Plex Mono',monospace", fontSize: 10, color: 'var(--dim)', lineHeight: 1.6, borderTop: '1px solid var(--border)', paddingTop: 10, marginTop: 4 }}>
              💬 {r.note}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function WatchlistTab({ stocks, results, onRemove, onRunWL, scanning }) {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
        <h2 style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 32, letterSpacing: '.04em', color: 'var(--gold)' }}>★ WATCHLIST</h2>
        {stocks.length > 0 && (
          <button onClick={onRunWL} disabled={scanning}
            style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 9, letterSpacing: '.1em', textTransform: 'uppercase', border: '1px solid var(--gold)', background: 'var(--gold-dim)', color: 'var(--gold)', padding: '8px 16px', cursor: 'pointer' }}>
            ▶ SCAN WATCHLIST
          </button>
        )}
      </div>
      {stocks.length === 0 ? (
        <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 12, color: 'var(--dim)', textAlign: 'center', padding: '60px 20px' }}>
          กด ☆ บนหุ้นที่ต้องการเพื่อเพิ่มใน Watchlist
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {stocks.map(s => (
            <StockRow key={s.sym} stock={s} result={results[s.sym]} expanded={false} onExpand={() => {}} inWL={true} onToggleWL={() => onRemove(s.sym)} />
          ))}
        </div>
      )}
    </div>
  );
}

function HistoryTab({ history }) {
  return (
    <div>
      <h2 style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 32, letterSpacing: '.04em', color: 'var(--text)', marginBottom: 24 }}>◷ SCAN HISTORY</h2>
      {history.length === 0 ? (
        <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 12, color: 'var(--dim)', textAlign: 'center', padding: '60px 20px' }}>
          ยังไม่มีประวัติ — รัน Screener ก่อน
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {history.map((h, i) => (
            <div key={i} style={{ background: 'var(--s1)', border: '1px solid var(--border)', padding: '14px 18px', display: 'flex', gap: 24, alignItems: 'center', flexWrap: 'wrap' }}>
              <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 11, color: 'var(--dim)', flex: 1 }}>{h.ts}</div>
              <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 11 }}>Scanned: <span style={{ color: 'var(--text)' }}>{h.scanned}</span></div>
              <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 11 }}>Pass: <span style={{ color: 'var(--green)' }}>{h.passCount || 0}</span></div>
              <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 11 }}>Review: <span style={{ color: 'var(--yellow)' }}>{h.revCount || 0}</span></div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
