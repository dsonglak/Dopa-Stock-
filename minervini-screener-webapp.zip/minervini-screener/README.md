# Minervini Trend Template Screener — Web App

เครื่องมือคัดกรองหุ้น Top 100 US ด้วย Minervini's 8-Criteria Trend Template

## ฟีเจอร์

- **Screener** — สแกน 100 หุ้นด้วย AI (Claude) ประเมิน 8 เกณฑ์อัตโนมัติ
- **Watchlist** — บันทึกหุ้นที่สนใจ สแกนเฉพาะ WL ได้
- **Custom Stocks** — เพิ่มหุ้นนอกรายการ Top 100 เองได้
- **Export CSV** — ดาวน์โหลดผลการสแกนเป็น Excel-compatible CSV
- **History** — ดูประวัติการสแกนย้อนหลัง
- **Persistent** — บันทึกผลลง localStorage ไม่ต้องสแกนซ้ำทุกครั้ง
- **Sort & Filter** — เรียงลำดับ กรอง PASS/REVIEW/FAIL/Watchlist ค้นหา Ticker

## วิธีรัน (Local)

### ต้องการ: Node.js 16+

```bash
# 1. ติดตั้ง dependencies
npm install

# 2. รัน development server
npm start

# เปิด http://localhost:3000
```

### Build for production
```bash
npm run build
# อัปโหลดโฟลเดอร์ build/ ไปที่ Vercel / Netlify / GitHub Pages
```

## Deploy บน Vercel (ฟรี)

1. Push โค้ดขึ้น GitHub
2. ไป https://vercel.com → Import repository
3. Framework: Create React App → Deploy
4. ได้ URL สาธารณะทันที

## 8 เกณฑ์ Trend Template

| # | เกณฑ์ |
|---|-------|
| C1 | Price > 150d MA & 200d MA |
| C2 | 150d MA > 200d MA |
| C3 | 200d MA uptrending ≥ 1 month |
| C4 | 50d MA > 150d MA & 200d MA |
| C5 | Price > 50d MA |
| C6 | Price ≥ 25% above 52-week Low |
| C7 | Price within 25% of 52-week High |
| C8 | RS Rating ≥ 70 |

> ⚠️ ผลเป็นการประมาณโดย AI เพื่อการศึกษาเท่านั้น ไม่ใช่คำแนะนำการลงทุน

---
*Built with React + Claude AI (Anthropic API)*
